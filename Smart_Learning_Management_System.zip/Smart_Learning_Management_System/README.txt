LearnSphere — Smart Learning Management System

HOW TO RUN
1. Extract the ZIP folder.
2. Open the folder.
3. Double-click index.html (or right-click > Open with > Chrome).
4. No installation, server, database, or internet connection is required.

FEATURES
- Overview dashboard with course progress, tasks, study rhythm and learning insight
- Add courses and update course progress
- Add assignments and mark them complete
- Smart Study Planner that creates a timed study routine
- Concept Rescue Room: guided recovery card for difficult concepts
- Focus Room with a working Pomodoro timer
- Learning insights and profile settings
- Saves courses, tasks, focus minutes and profile in browser localStorage

DEMO DATA
The dashboard starts with sample courses and assignments. You can edit/add your own data.
Data is saved in the browser where you opened the dashboard. Clearing browser storage will reset it.

IMPORTANT
Concept Rescue is a local guided template in this version; it is not connected to a live AI model,
student login system, cloud database, or teacher portal. Those can be added in a backend-integrated version.
